#ifndef CGIMAGEDESTINATION_H_
#define CGIMAGEDESTINATION_H_
#define CGIMAGEDESTINATION_FALLBACK 1
typedef struct CGImageDestination *CGImageDestinationRef;
#endif
